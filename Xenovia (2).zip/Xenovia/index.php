<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="code/styles.css">
</head>
<body>
  <!--Videobg-->
    <div class="video-background">
    <video autoplay muted loop>
      <source src="background/hu-tao-scary-genshin-impact-moewalls-com.mp4" type="video/mp4">
      Your browser does not support the video tag.
    </video>
    <div class="content">
      <h1>Xenovia</h1>
      <p>Welcome to Xenovia</p>
      <a href="data/store.php" id="startButton">Start</a>
    </div>
  </div>
  <!--Videobg-->
  
</body>
</html>
