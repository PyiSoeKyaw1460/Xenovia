-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 09, 2024 at 08:27 AM
-- Server version: 5.5.20
-- PHP Version: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `xenovia`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE IF NOT EXISTS `brands` (
  `b_id` int(100) NOT NULL AUTO_INCREMENT,
  `b_title` text NOT NULL,
  PRIMARY KEY (`b_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`b_id`, `b_title`) VALUES
(1, 'Apple'),
(2, 'Samsaung'),
(3, 'Dell'),
(4, 'Xiaomi'),
(5, 'Lenevo'),
(6, 'Hp'),
(7, 'Acer'),
(8, 'Nvidia'),
(9, 'Motherboard '),
(10, 'Earbuds'),
(11, 'Asus'),
(12, 'Msi');

-- --------------------------------------------------------

--
-- Table structure for table `buy`
--

CREATE TABLE IF NOT EXISTS `buy` (
  `brand` varchar(20) NOT NULL,
  `model` varchar(30) NOT NULL,
  `price` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `delivery` varchar(20) NOT NULL,
  `address` varchar(200) NOT NULL,
  `Order_no` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buy`
--

INSERT INTO `buy` (`brand`, `model`, `price`, `phone`, `delivery`, `address`, `Order_no`) VALUES
('JLab', 'Go airpod', '19.99$', '09961618132', 'Cash on delivery', 'Yangon', 'no14'),
('Earbuds', 'Bose', '299.00$', '987898', 'Pay pal', ',dbv', 'no316'),
('Earbuds', 'Bose', '299.00$', '987898', 'Pay pal', ',dbv', 'no891'),
('Earbuds', 'Bose', '299.00$', '324', 'Cash on delivery', 'dx', 'no602');

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE IF NOT EXISTS `content` (
  `con_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `mesg` varchar(50) NOT NULL,
  PRIMARY KEY (`con_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `content`
--

INSERT INTO `content` (`con_id`, `name`, `email`, `phone`, `mesg`) VALUES
(11, 'aung', 'aa@gmail.com', '09777777777', 'Hello');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `p_id` int(100) NOT NULL AUTO_INCREMENT,
  `p_brand` text NOT NULL,
  `p_model` varchar(100) NOT NULL,
  `p_price` varchar(100) NOT NULL,
  `p_image` text NOT NULL,
  `p_desc` varchar(255) NOT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=67 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`p_id`, `p_brand`, `p_model`, `p_price`, `p_image`, `p_desc`) VALUES
(24, 'Apple', 'Macbook pro', '577.95$', 'Apple_MC373LL_A_15_4_MacBook_Pro_Notebook_684524.jpg', 'Cpu: i7 2.66 GHz\r\nRam: 16GB\r\nSsd: 256GB\r\nColor: Gray\r\nOs: macOS 10.13 High Sierra\r\nSize: 15.4inch\r\n'),
(25, 'Hp', 'Envy', '845.19$', '61XblXYWwuL._AC_UY327_FMwebp_QL65_.jpg', 'Cpu: i7\r\nRam: 16GB\r\nStroage: 512GB\r\nResolutions: 1920x1080\r\nColor: Gray\r\nSize: 15.6inch'),
(26, 'Asus', 'Asus Vivobook', '359.00$', '61QYxptc9SL._AC_SS450_.jpg', 'Cpu: Ryzen 7 5800H\r\nRam: 12GB\r\nStroage: 512GB\r\nColor: Quiet Blue\r\nsize: 16inch\r\nOs: Window 11 Home'),
(27, 'Dell', 'Dell Inspiron 15', '990.00$', '61XxMkA7EAL._AC_UY327_FMwebp_QL65_.jpg', 'Cpu:i7 13th Gen\r\nRam: 64GB\r\nStroage: 2TB\r\ncolor: Black\r\nSize: 15.6inch\r\nOs: window 11'),
(28, 'Xiaomi', 'Xiaomi PocoX5', '207.00$', '51tqdlQSgqL._AC_UY327_FMwebp_QL65_.jpg', 'Ram: 8GB\r\nColor: Black(Global Version\r\nOs: MIUI 13 Base on Android 11\r\nStroage: 256GB\r\nDisplay: Super AMOLED 120Hz\r\nCameras: 48 MP, f/1.8, (wide), PDAF | 8 MP, f/2.2, (ultrawide) | 2 MP, f/2.4, (macro) | 13 MP, f/2.5, (wide)\r\nBattery: Li-Po 5000 mAh, non-'),
(29, 'Xiaomi', 'Xiaomi PocoF5 5G', '519.99$', '51s8pXxHnnL._AC_SY679_.jpg', 'Ram: 12GB\r\nOs: android 13\r\nResolution: 2560x1440\r\nColor: White(Global)\r\nDual SIM: 5G+5G 5G: SNetwork bands:Supports 5G* / 4G / 3G/ 2G5G Sub6G: /3/5/7/8/20/28/38/40/41/77/784G LTE FDD: /2/3/4/5/7/8/20/28/66(NarrowBand)4G LTE TDD: B38/40/413G WCDMA: B1/2/4/'),
(30, 'Xiaomi', 'Xiaomi Mi 13 Ultra', '819.00$', '610LxfqhohL._AC_UY327_FMwebp_QL65_.jpg', '\r\nBrand	Xiaomi\r\nModel Name	Mi 13 Ultra\r\nWireless Carrier	Unlocked\r\nOperating System	Android 13.0\r\nCellular Technology	5G\r\nMemory Storage Capacity	256 GB\r\nConnectivity Technology	Wi-Fi\r\nScreen Size	6.67 Inches\r\nWireless network technology	GSM, LTE\r\nRam Mem'),
(31, 'Earbuds', 'Samsung buds pro2', '107.00$', '61ReFn+YL1L._AC_UY327_FMwebp_QL65_.jpg', '\r\nBrand	SAMSUNG\r\nModel Name	Samsung Galaxy Buds Pro 2\r\nColor	Gray\r\nForm Factor	In Ear\r\nConnectivity Technology	Wireless'),
(35, 'Samsaung', 'Galaxy A34 5G', '209.99$', '51In7TyRHIL._AC_UY327_FMwebp_QL65_.jpg', '\r\nBrand	SAMSUNG\r\nModel Name	Galaxy A34 5G\r\nWireless Carrier	Unlocked for All Carriers\r\nOperating System	Android 12, One UI Core 4.1\r\nCellular Technology	2G, 3G, 4G, 5G\r\nMemory Storage Capacity	128 GB\r\nConnectivity Technology	Wi-Fi\r\nColor	Awesome Silver (S'),
(36, 'Earbuds', 'Bose', '299.00$', '51DOzlkiBTL._AC_UY327_FMwebp_QL65_.jpg', '\r\nBrand	Bose\r\nModel Name	Bose QuietComfort Ultra Wireless Noise Cancelling Earbuds, Bluetooth Noise Cancelling Earbuds with Spatial Audio and World-Class Noise Cancellation, BlackBose QuietComfort Ultra Wireless Noise Cancelling Earbuds, Bluetooth Noise C'),
(37, 'Earbuds', 'Sony WF1000XM5', '278.00$', '61qmsGnacvL._AC_UY327_FMwebp_QL65_.jpg', 'Brand	Sony\r\nModel Name	WF1000XM5/S\r\nColor	Silver\r\nForm Factor	In Ear\r\nConnectivity Technology	Bluetooth 5.3'),
(41, 'Asus', 'ASUS K3704VA', '999.99$', '71gLz5gSDjL._AC_UY327_FMwebp_QL65_.jpg', 'Brand	ASUS\nModel Name	K3704VA-DH96-S\nScreen Size	17.3 Inches\nColor	Transparent Silver\nCPU Model	Core i9\nRam Memory Installed Size	16 GB\nOperating System	Windows 11 Home\nGraphics Card Description	Integrated\nGraphics Coprocessor	Intel Iris\nCPU Sp'),
(45, 'Hp', 'Hp Probook 440G7', '625.00$', '71eHle2z84L._AC_UY327_FMwebp_QL65_.jpg', '\r\nBrand	HP\r\nModel Name	SBUY PB440G7\r\nScreen Size	14 Inches\r\nHard Disk Size	256 GB\r\nCPU Model	Core i5\r\nRam Memory Installed Size	8 GB\r\nOperating System	Intel\r\nGraphics Card Description	Integrated\r\nGraphics Coprocessor	Intel UHD Graphics 620\r\nCPU Speed	1.6 '),
(48, 'Asus', 'Asus Phoenix', '210.00$', '719xOPMalsL._AC_UY327_FMwebp_QL65_.jpg', '\r\nGraphics Coprocessor	NVIDIA GeForce RTX 3050\r\nBrand	ASUS\r\nGraphics Ram Size	8 GB\r\nGPU Clock Speed	1.81 GHz\r\nVideo Output Interface	PCI Express'),
(49, 'Dell', 'Dell Vostro 3520', '606.99$', '71O8sNbVRwL._AC_UY327_FMwebp_QL65_.jpg', 'Brand	Dell\r\nModel Name	Vostro 3520\r\nScreen Size	15.6 Inches\r\nColor	Black\r\nHard Disk Size	1 TB\r\nCPU Model	Core i5 Family\r\nRam Memory Installed Size	32 GB\r\nOperating System	Windows 11 Pro\r\nSpecial Feature	Numeric Keypad\r\nGraphics Card Description	Integrated'),
(50, 'Earbuds', 'JLab Go Airpod', '19.99$', '71sxbX6aCEL._AC_UY327_FMwebp_QL65_.jpg', '\r\nBrand	JLab\r\nModel Name	Go Air Sport\r\nColor	Teal\r\nForm Factor	In Ear\r\nConnectivity Technology	Wireless'),
(51, 'Dell', 'Dell XPS 15 9520', '1199.00$', '716T+1iVYqL._AC_UY327_FMwebp_QL65_.jpg', '\r\nBrand	Dell\r\nModel Name	Dell Inspiron\r\nScreen Size	15.6 Inches\r\nColor	Platinum Silver exterior, Black interior\r\nHard Disk Size	1 TB\r\nCPU Model	Core i7\r\nRam Memory Installed Size	16 GB\r\nOperating System	Windows 11 Pro\r\nSpecial Feature	Backlit Keyboard, An'),
(52, 'Motherboard ', 'Asus ROGstrix B550', '128.52$', '813WBwlPh+L._AC_UY327_FMwebp_QL65_.jpg', 'Brand	ASUS\r\nCPU Socket	Socket AM4\r\nCompatible Devices	Personal Computer\r\nRAM Memory Technology	DDR4\r\nCompatible Processors	AMD 3rd Generation Ryzen\r\nChipset Type	AMD B550\r\nMemory Clock Speed	2133 MHz\r\nPlatform	Windows 95\r\nModel Name	ROG STRIX B550-F GAMIN'),
(53, 'Motherboard ', 'Gigabyte B550 V2', '108.0$', '715QyzBTaRL._AC_UY327_FMwebp_QL65_.jpg', 'Brand	GIGABYTE\r\nCPU Socket	Socket AM4\r\nCompatible Devices	Gaming Console\r\nRAM Memory Technology	DDR4\r\nCompatible Processors	AMD 3rd Generation Ryzen\r\nChipset Type	AMD B550\r\nMemory Clock Speed	2133 MHz\r\nPlatform	Windows 10\r\nModel Name	B550 AORUS\r\nMemory St'),
(54, 'Msi', 'Msi Raider GE76', '1365.00$', '71Ki7Jjys9L._AC_UY327_FMwebp_QL65_.jpg', '\r\nBrand	MSI\r\nModel Name	Raider GE76 12UE-871\r\nScreen Size	17.3 Inches\r\nColor	Black\r\nHard Disk Size	1 TB\r\nCPU Model	Core i9\r\nRam Memory Installed Size	16 GB\r\nOperating System	Windows 11 Home\r\nSpecial Feature	Numeric Keypad\r\nGraphics Card Description	Dedica'),
(55, 'Msi', 'Msi Modern14', '419.19$', '5113DmAMnIL._AC_UY327_FMwebp_QL65_.jpg', 'Brand	MSI\r\nScreen Size	14 Inches\r\nHard Disk Size	512 GB\r\nCPU Model	Core i5\r\nRam Memory Installed Size	16 GB\r\nOperating System	Windows 11 Home\r\nGraphics Card Description	Integrated\r\nCPU Speed	2.4 GHz\r\nHard Disk Description	SSD\r\nResolution	1080p'),
(56, 'Nvidia', 'NVIDIA RTX 5000', '859.99$', '41Ju3BmfGYL._AC_UY327_FMwebp_QL65_.jpg', 'Graphics Coprocessor	NVIDIA Quadro RTX 5000\r\nBrand	PNY\r\nGraphics Ram Size	16 GB\r\nVideo Output Interface	DisplayPort\r\nGraphics Processor Manufacturer	NVIDIA'),
(57, 'Samsaung', 'Galaxy Tab S9 FE+', '412.00$', '41GcCeBaq5L._AC_UY327_FMwebp_QL65_.jpg', '\r\nBrand	SAMSUNG\r\nModel Name	Tab S9 FE+\r\nMemory Storage Capacity	8 GB\r\nScreen Size	12.4\r\nDisplay Resolution Maximum	2560 x 1600 (WQXGA)\r\n'),
(58, 'Samsaung', 'Galaxy book3', '1105.99$', '71IqYm24D+L._AC_UY327_FMwebp_QL65_.jpg', 'Brand	SAMSUNG\r\nModel Name	Galaxy Book3 Pro\r\nScreen Size	16 Inches\r\nColor	Graphite\r\nHard Disk Size	1 TB\r\nCPU Model	Core i7\r\nRam Memory Installed Size	32 GB\r\nOperating System	Windows 11 Pro\r\nSpecial Feature	Eye Care\r\nGraphics Card Description	Integrated'),
(59, 'Samsaung', 'GALAXY S23 Ultra', '899.99$', '51mH1rGI3lL._AC_UY327_FMwebp_QL65_.jpg', '\r\nBrand	SAMSUNG\r\nModel Name	SAMSUNG Galaxy S23 Ultra 5G\r\nWireless Carrier	Unlocked for All Carriers\r\nOperating System	Android 13.0\r\nCellular Technology	5G\r\nMemory Storage Capacity	256 GB\r\nConnectivity Technology	Wi-Fi\r\nColor	Green\r\nScreen Size	6.8 Inches\r'),
(60, 'Select brands', 'Galaxy A34 5G', '209.00$', '51In7TyRHIL._AC_UY327_FMwebp_QL65_.jpg', 'Brand	SAMSUNG\r\nModel Name	Galaxy A34 5G\r\nWireless Carrier	Unlocked for All Carriers\r\nOperating System	Android 12, One UI Core 4.1\r\nCellular Technology	2G, 3G, 4G, 5G\r\nMemory Storage Capacity	128 GB\r\nConnectivity Technology	Wi-Fi\r\nColor	Awesome Silver (SM-'),
(61, 'Apple', 'Iphone 15pro', '4799.95$', '61RklF9NgpL._AC_UY327_QL65_.jpg', '\r\nBrand	Never Run Out\r\nWireless Carrier	Unlocked\r\nCellular Technology	4G\r\nMemory Storage Capacity	128 GB\r\nColor	Purple\r\nWireless network technology	Wi-Fi\r\nConnector Type	USB Type C\r\nForm Factor	Smartphone\r\nBattery Capacity	4 Milliamp Hours\r\nBiometric Secu'),
(62, 'Asus', 'Asus ROG Diablo', '729.99$', '81sgTjFB4RL._AC_UY327_FMwebp_QL65_.jpg', '\r\nBrand	Never Run Out\r\nWireless Carrier	Unlocked\r\nCellular Technology	4G\r\nBrand	ASUS\r\nModel Name	ROG Phone 6 Diablo Immortal Edition\r\nWireless Carrier	Unlocked\r\nOperating System	Android 12.0\r\nCellular Technology	5G\r\nMemory Storage Capacity	16 GB\r\nConnecti'),
(63, 'Hp', 'Hp Pavilion X360', '509.00$', '81BLK5ExrbL._AC_UY327_FMwebp_QL65_.jpg', '\r\nBrand	HP\r\nModel Name	Pavilion x360 2-in-1\r\nScreen Size	14 Inches\r\nColor	Natural Silver\r\nHard Disk Size	512 GB\r\nCPU Model	Intel Core i5\r\nRam Memory Installed Size	8 GB\r\nOperating System	Windows 11\r\nSpecial Feature	Work. Write. Play. Naturally. The 360-de'),
(64, 'Lenevo', 'Lenovo Idea pad3i', '364.00$', '71+OtOOXYaL._AC_UY327_FMwebp_QL65_.jpg', '\r\nBrand	Lenovo\r\nModel Name	IdeaPad\r\nScreen Size	14 Inches\r\nColor	Grey\r\nHard Disk Size	1 TB\r\nCPU Model	Core i3 Family\r\nRam Memory Installed Size	20 GB\r\nOperating System	Windows 11 Home\r\nSpecial Feature	Dolby\r\nGraphics Card Description	Integrated'),
(65, 'Lenevo', 'Lenovo Idea pad3', '263.33$', '61QGMX0Qy6L._AC_UY327_FMwebp_QL65_.jpg', '\r\nBrand	Lenovo\r\nModel Name	IdeaPad 3 81X800ENUS\r\nScreen Size	15.6 Inches\r\nColor	Almond\r\nHard Disk Size	256 GB\r\nCPU Model	Core i3\r\nRam Memory Installed Size	20 GB\r\nOperating System	Windows 11\r\nSpecial Feature	Backlit Keyboard\r\nGraphics Card Description	Int'),
(66, 'Lenevo', 'Lenovo Thinkpad 14s', '969.00$', '51YqzUmC+sL._AC_UY327_FMwebp_QL65_.jpg', '\r\nBrand	Lenovo\r\nModel Name	ThinkPad T14s Gen 3\r\nScreen Size	14 Inches\r\nColor	Storm Grey\r\nHard Disk Size	512 GB\r\nCPU Model	Core i7\r\nRam Memory Installed Size	16 GB\r\nOperating System	Windows 11 Pro\r\nSpecial Feature	Anti-glare Screen\r\nGraphics Card Descripti');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE IF NOT EXISTS `register` (
  `reg_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(10) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `city` varchar(30) NOT NULL,
  `township` varchar(30) NOT NULL,
  PRIMARY KEY (`reg_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`reg_id`, `name`, `email`, `password`, `phone`, `city`, `township`) VALUES
(19, 'thuthu', 'tt@gmail.com', '1234', '0999999999999', 'ygn', 'kamayut'),
(21, 'Rin', 'rin@gmail.com', '1234', '09111111', 'Yangon', 'South Dagon');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `name` varchar(30) NOT NULL,
  `pass` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `pass`) VALUES
('admin', '1234');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
