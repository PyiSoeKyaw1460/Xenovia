document.addEventListener('DOMContentLoaded', function () {
  const burgerMenu = document.querySelector('.burger-menu');
  const navLinks = document.querySelector('.nav-links');
  const slider = document.querySelector('.slider');
  let currentIndex = 0;

  function nextSlide() {
    currentIndex = (currentIndex + 1) % 3;
    updateSlider();

  burgerMenu.addEventListener('click', function () {
    navLinks.classList.toggle('show');
  });

  feedbackForm.addEventListener('submit', function (event) {
    event.preventDefault();
    // You can add logic here to handle the form submission, e.g., sending data to a server.

    // For demonstration purposes, let's log the form data to the console.
    const formData = new FormData(feedbackForm);
    for (const entry of formData.entries()) {
      console.log(`${entry[0]}: ${entry[1]}`);
    }

    // You can also reset the form after submission if needed.
    feedbackForm.reset();
  });


  }

  function updateSlider() {
    const translateValue = -currentIndex * 100;
    slider.style.transform = `translateX(${translateValue}%)`;
  }

  // Auto-advance the slider every 3 seconds
  setInterval(nextSlide, 3000);
});


