<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="code/styles.css">

  <title>Xenovia</title>

  <?php
  session_start();
  error_reporting(1);
  
  include("connection.php");
  
  if($_REQUEST['log']=='out')
  {
    session_destroy();
    header("location:store.php");
  }
  
?>
<style>
  .mainbar p{font-size:16px; font-weight:bold;};
</style>
</head>

<body background="background/background.jpg">
<header>
  <!--nav start-->
    <div class="navbar">
            <div class="logo">Xenovia</div>
            <nav>
                <ul class="nav-links">
                <a href="store.php">Store</a>&nbsp; &nbsp; &nbsp;
                <a href="contact.php">Contact us</a>&nbsp; &nbsp; &nbsp;
                <a href="about.php">About us</a>&nbsp; &nbsp; &nbsp;
                <font color="white">
                <?php
                    if(strlen($_SESSION['sid'])==0){
                      echo "<a href='register.php'>Register</a>&nbsp; &nbsp; &nbsp;";
                          echo "<a href='login.php'>Login</a>&nbsp; &nbsp; &nbsp;" ;
                          }else{
                            echo $_SESSION['email'];
                          }
                  ?>
                </font>
                </ul>
                <div class="hamburger">
                    <div class="line"></div>
                    <div class="line"></div>
                    <div class="line"></div>
                </div>
            </nav>
        </div>
    
    <div class="sidenav">
        <a href="store.php">Store</a>
        <a href="register.php">Register</a>
        <a href="login.php">Login</a>
        <a href="contact.php">Contact us</a>
        <a href="contact.php">About us</a>
    </div>
    <script>
      document.querySelector('.hamburger').addEventListener('click', () => {
      document.querySelector('.sidenav').style.width = '250px';
      });

      // document.querySelector('.sidenav').addEventListener('click', () => {
      // document.querySelector('.sidenav').style.width = '0';
      // });

      let slideIndex = 0;
    </script>
    <!--nav end-->
  </header>

    <!-- Footer start -->
  <footer class="footer">
    <div class="waves">
      <div class="wave" id="wave1"></div>
      <div class="wave" id="wave2"></div>
      <div class="wave" id="wave3"></div>
      <div class="wave" id="wave4"></div>
    </div>
    <ul class="social-icon">
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-facebook"></ion-icon>
        </a></li>
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-twitter"></ion-icon>
        </a></li>
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-linkedin"></ion-icon>
        </a></li>
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-instagram"></ion-icon>
        </a></li>
    </ul>
    <ul class="menu">
      <li class="menu__item"><a class="menu__link" href="store.php">Store</a></li>
      <li class="menu__item"><a class="menu__link" href="register.php">Register</a></li>
      <li class="menu__item"><a class="menu__link" href="login.php">Login</a></li>
      <li class="menu__item"><a class="menu__link" href="contact.php">Contact us</a></li>
      <li class="menu__item"><a class="menu__link" href="about.php">About us</a></li>

    </ul>
    <p>&copy;2024 Xenovia | All Rights Reserved</p>
  </footer>
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
  
<script src="script.js"></script>
</body>
</html>
