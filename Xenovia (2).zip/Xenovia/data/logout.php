<?php
session_start();
unset($_SESSION['sid']);
header('location:store.php');
?>