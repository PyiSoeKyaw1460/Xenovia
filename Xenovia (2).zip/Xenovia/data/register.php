<?php 
session_start();
error_reporting(1);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="code/styles.css">
  <title>Responsive Nav</title>
</head>
<body background="background/background.jpg">
<header>
  <!--nav start-->
    <div class="navbar">
            <div class="logo">Xenovia</div>
            <nav>
                <ul class="nav-links">
                <a href="store.php">Store</a>&nbsp; &nbsp; &nbsp;
                <a href="contact.php">Contact us</a>&nbsp; &nbsp; &nbsp;
                <a href="about.php">About us</a>&nbsp; &nbsp; &nbsp;
                <font color="white">
                <?php
                    if(strlen($_SESSION['sid'])==0){
                      echo "<a href='register.php'>Register</a>&nbsp; &nbsp; &nbsp;";
                          echo "<a href='login.php'>Login</a>&nbsp; &nbsp; &nbsp;" ;
                          }else{
                            echo $_SESSION['email'];
                          }
                  ?>
                </font>
                </ul>
                <div class="hamburger">
                    <div class="line"></div>
                    <div class="line"></div>
                    <div class="line"></div>
                </div>
            </nav>
        </div>
    
    <div class="sidenav">
        <a href="store.php">Store</a>
        <a href="register.php">Register</a>
        <a href="login.php">Login</a>
        <a href="contact.php">Contact us</a>
        <a href="contact.php">About us</a>
    </div>
    <script>
      document.querySelector('.hamburger').addEventListener('click', () => {
      document.querySelector('.sidenav').style.width = '250px';
      });

      // document.querySelector('.sidenav').addEventListener('click', () => {
      // document.querySelector('.sidenav').style.width = '0';
      // });

      let slideIndex = 0;
    </script>
    <!--nav end-->
  </header>

  <!--register form-->
  <div class="register-form">
    <h2>Registeration</h2>
<?php
include("connection.php");
if($_POST['sub'])
{ 
$name     =$_POST['t1'];
$email    =$_POST['t2'];
$password =$_POST['t3'];
$phone    =$_POST['t4'];
$city     =$_POST['t5'];
$town     =$_POST['t6'];
 if(mysql_query("INSERT into register(name,email,password,phone,city,township) values('$name','$email','$password','$phone','$city','$town')"))
// $ret = mysqli_query($con, "SELECT email FROM register where email='$email'");
// $result=mysqli_fetch_array($ret);

// {
// echo "<script>location.href='reg_success.php?name=$name & email=$email'</script>";}
 header("location:reg_success.php?name=$name & email=$email");}
//else {$error= "user already exists";}

// if($result != null){
//   echo "<script>alert('This email is already exists!')</script>";
// } else {
//     $query = mysqli_query($con,"INSERT into register(name,email,password,phone,city,township) values('$name','$email','$password','$phone','$city','$town')");

//     if ($query) {
//       echo "<script>alert('You have successfully registered!')</script>";
//     }
// }
// }

?>
            <form  method="post">
                <label>Name </label>
                <input type="text" name="t1" id="t1" class="input_field" required>
                <label>Email</label>
                <input type="email" name="t2" id="t2" class="input_field" required>
                <label>Password</label>
                <input type="password" name="t3" id="t3" class="input_field" required>
                <label>Phone</label>
                <input type="text" name="t4" id="t4" class="input_field" required>
                <label>City</label>
                <input type="text" name="t5" id="t5" class="input_field" required>
                <label>Town</label>
                <input type="text" name="t6" id="t6" class="input_field" required>
                <input type="submit" name="sub" id="sub" value="Register" class="submit_button" />
         <input type="reset" name="Cancel" value="Cancel" class="submit_button" />
        <label><?php echo "<font color='red'>$error</font>";?></label>
            </form>
</div>
<!--register form end-->

  <!-- Footer start -->
  <footer class="footer">
    <div class="waves">
      <div class="wave" id="wave1"></div>
      <div class="wave" id="wave2"></div>
      <div class="wave" id="wave3"></div>
      <div class="wave" id="wave4"></div>
    </div>
    <ul class="social-icon">
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-facebook"></ion-icon>
        </a></li>
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-twitter"></ion-icon>
        </a></li>
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-linkedin"></ion-icon>
        </a></li>
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-instagram"></ion-icon>
        </a></li>
    </ul>
    <ul class="menu">
      <li class="menu__item"><a class="menu__link" href="store.php">Store</a></li>
      <li class="menu__item"><a class="menu__link" href="register.php">Register</a></li>
      <li class="menu__item"><a class="menu__link" href="login.php">Login</a></li>
      <li class="menu__item"><a class="menu__link" href="contact.php">Contact us</a></li>
      <li class="menu__item"><a class="menu__link" href="about.php">About us</a></li>

    </ul>
    <p>&copy;2024 Xenovia | All Rights Reserved</p>
  </footer>
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

  <script src="script.js"></script>
</body>
</html>
