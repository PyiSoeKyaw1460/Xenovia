<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="code/styles.css">

  <title>Xenovia</title>

  <?php
  error_reporting(1);
  
  include("connection.php");
  
  $product_brand = $_REQUEST['buy_pro'];
  
  if(isset($_REQUEST['buy']))
  {
    $b = $_REQUEST['b'];
    $m = $_REQUEST['m'];
    $p = $_REQUEST['p'];
    $phno = $_REQUEST['phno'];
    $delivery = $_REQUEST['r'];
    $add = $_REQUEST['add'];
    $order_no = no.rand(100,999);
    if(mysql_query("INSERT INTO buy VALUES('$b', '$m', '$p', '$phno', '$delivery', '$add', '$order_no')"))
    {
      echo "<script>location.href='buysuccess.php?order_no=$order_no'</script>";
    }
  }
?>
</head>

<body background="background/background.jpg">

<header>
  <!--nav start-->
    <div class="navbar">
            <div class="logo">Xenovia</div>
            <nav>
                <ul class="nav-links">
                <a href="store.php">Store</a>&nbsp; &nbsp; &nbsp;
                <a href="contact.php">Contact us</a>&nbsp; &nbsp; &nbsp;
                <font color="white">
                <?php
                    if(strlen($_SESSION['sid'])==0){
                      echo "<a href='register.php'>Register</a>&nbsp; &nbsp; &nbsp;";
                          echo "<a href='login.php'>Login</a>&nbsp; &nbsp; &nbsp;" ;
                          }else{
                            echo $_SESSION['email'];
                          }
                  ?>
                </font>
                </ul>
                <div class="hamburger">
                    <div class="line"></div>
                    <div class="line"></div>
                    <div class="line"></div>
                </div>
            </nav>
        </div>
    
    <div class="sidenav">
        <a href="store.php">Store</a>
        <a href="register.php">Register</a>
        <a href="login.php">Login</a>
        <a href="contact.php">Contact</a>
    </div>
    <script>
      document.querySelector('.hamburger').addEventListener('click', () => {
      document.querySelector('.sidenav').style.width = '250px';
      });

      // document.querySelector('.sidenav').addEventListener('click', () => {
      // document.querySelector('.sidenav').style.width = '0';
      // });

      let slideIndex = 0;
    </script>
    <!--nav end-->
  </header>

    <div class="content">
      
        <h2>Buy a product</h2>
     
      </p>
      <p><font color="white">If you want to order what you've choosen, please fill the following order form.</font></p>
      <p><font color="white">Our standard delivery is 5 days and delivery fee is $5. But if you preferred a rush, you can choose 3 days or next day. Delivery fee is $7.</font></p>
      <p><font color="pink">Thank you. Enjoy your shopping!!</font></p>
        <form method="post">
      <?php        
        $sel=mysql_query("select * from product where p_id='$product_brand'");
        $mat=mysql_fetch_array($sel);
      ?>
      <table border="0" cellpadding="10px">
        <tr>
          <td>Brand</td>
          <td><input type="text" name="b" value="<?php echo $mat['p_brand']; ?>"></td>
        </tr>
        <tr>
          <td>Model</td>
          <td><input type="text" name="m" value="<?php echo $mat['p_model']; ?>"></td>
        </tr>
        <tr>
          <td>Price</td>
          <td><input type="text" name="p" value="<?php echo $mat['p_price']; ?>"></td>
        </tr>
        <tr>
          <td>Phone Number</td>
          <td><input type="text" name="phno" required></td>
        </tr>
        <tr>
          <td>Preferred Delivery</td>
          <td><input type="radio" name="r" value="Pay pal" required>Pay pal
              <input type="radio" name="r" value="Visa" required>Visa
            <input type="radio" name="r" value="Cash on delivery" required>Cash on delivery
          </td>
        </tr>
        <tr>
          <td>Address</td>
          <td><textarea name="add" required></textarea></td>
        </tr>
        <tr>
          <td colspan="2" align="center"><input type="submit" name="buy" value="Buy"> &nbsp;
                          <input type="reset" value="Cancel">
          </td>
        </tr>
    
      </table>
    </form>

    </div>

      <!-- Footer start -->
  <footer class="footer">
    <div class="waves">
      <div class="wave" id="wave1"></div>
      <div class="wave" id="wave2"></div>
      <div class="wave" id="wave3"></div>
      <div class="wave" id="wave4"></div>
    </div>
    <ul class="social-icon">
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-facebook"></ion-icon>
        </a></li>
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-twitter"></ion-icon>
        </a></li>
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-linkedin"></ion-icon>
        </a></li>
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-instagram"></ion-icon>
        </a></li>
    </ul>
    <ul class="menu">
      <li class="menu__item"><a class="menu__link" href="store.php">Store</a></li>
      <li class="menu__item"><a class="menu__link" href="register.php">Register</a></li>
      <li class="menu__item"><a class="menu__link" href="login.php">Login</a></li>
      <li class="menu__item"><a class="menu__link" href="contact.php">Contact</a></li>

    </ul>
    <p>&copy;2024 Xenovia | All Rights Reserved</p>
  </footer>
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
  
<script src="script.js"></script>
</body>
</html>
