<html>
<head>
<title>Admin Log in</title>

<link href="adminstyle.css" rel="stylesheet" type="text/css" />

<?php
	error_reporting(1);
	
	include("connection.php");
	
	if(isset($_POST['login']))
	{
		
		$uname = $_POST['uname'];
		$pass = $_POST['pass'];
		$check = mysqli_query($con, "SELECT name,pass FROM user WHERE name='$uname'");
		$run = mysqli_fetch_array($check);
		if($run['name']==$uname && $run['pass']==$pass)
		{
			echo "<script>location.href='home.php'</script>";
		}
		else
		{
			$error = "User name or Password do not match!";
		}
	
	}

?>

</head>
<body>
<div class="main">

 <div class="content">
    <!-- <div class="content_resize"> -->
    <div class="mainbar">
	<h2 align="center">Admin Log In</h2>
	<form method="post">
		<!-- <table border='0' cellpadding='10px'> -->
			<tr>
				<td colspan="2"><?php error_reporting(1); echo "<font color='red'>$error</font>"; ?> </td>
			</tr>
			<tr>
				<td>User Name</td>
				<td><input type="text" name="uname" required></td>
			</tr>
			<tr>
				<td>Password</td>
				<td><input type="password" name="pass" required></td>
			</tr>
			<tr>
				<td colspan="2"><input type="submit" name="login" value="Log In"></td>
			</tr>
		</table>
	</form>
	</div>
	</div>
  </div>

</div>
</body>
</html>
