<html>
<head>
<title>Contact</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="adminstyle.css" rel="stylesheet" type="text/css" />
<!-- CuFon: Enables smooth pretty custom font rendering. 100% SEO friendly. To disable, remove this section -->
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/arial.js"></script>
<script type="text/javascript" src="js/cuf_run.js"></script>
<!-- CuFon ends -->



</head>
<body>
<div class="main">

  <!-- Nav start -->
    <div class="sidenav">
    <a href="home.php">Home</a>
    <a href="insert_product.php">Add product</a>
    <a href="view_product.php">View product</a>
  </div>
  <!-- Nav end -->

  <div class="header">
	  <div class="clr"></div>
      
          
    </div>
  </div>

  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
          <h2>All contact from database</h2>
		  <?php
				 error_reporting(1);
	
				include("connection.php");
	
				$view = "SELECT * FROM content";
				$result = mysqli_query($con, $view);
				
				echo "<table border='1' cellspacing='0' cellpadding='15px'>";
				echo "<tr>
								<th>Full name</th>
						  	<th>Email</th>
					  	  <th>Phone</th>
					  	  <th>Message</th>
					  	 
					  </tr>
					 ";
				
				while(list($id,$name,$email, $phone, $mesg) = mysqli_fetch_array($result))
				{
					echo "<tr>";
					echo "<td>". $name  ."</td>";
					echo "<td>". $email ."</td>";
					echo "<td>". $phone ."</td>";
					echo "<td>". $mesg  ."</td>";
					echo "</tr>";
				}
				echo "</table>";
		  ?>
		  
			<p><a href="home.php">Go Back</a></p>
			
        </div>
        
      </div>
      
      <div class="clr"></div>
    </div>
  </div>
</div>
</body>
</html>
