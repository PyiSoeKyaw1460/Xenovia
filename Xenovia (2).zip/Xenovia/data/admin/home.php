<html>
<head>
<title>Home</title>

<link href="adminstyle.css" rel="stylesheet" type="text/css" />
<?php
	error_reporting(1);
	if($_REQUEST['log']=='out')
	{
		session_destroy();
		header("location:index.php");
	}
?>
</head>
<body>
<div class="main">

  <!-- Nav start -->
    <div class="sidenav">
    <a href="home.php">Home</a>
    <a href="insert_product.php">Add product</a>
    <a href="view_product.php">View product</a>
  </div>
  <!-- Nav end -->

  <div class="header">
	  <div class="clr"></div>
      
          
    </div>
  </div>

  <div class="content">
    <!-- <div class="content_resize"> -->
      <div class="mainbar">
        <div class="article">
			<h2>Welcome Admin!</h2>
			<ul class="sb_menu">
        <li><a href="contact.php">View contact</a></li>
				<li><a href="view_order.php">View order</a></li>
				<li><a href="?log=out">Log Out</a></li>
			</ul>
        </div>
        
      </div>
      
      <div class="clr"></div>
    </div>
  </div>

</div>
</body>
</html>
