<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="code/styles.css">

  <title>Xenovia</title>
  <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        header {
            color: #fff;
            padding: 20px;
            text-align: center;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
        }
        h2 {
            color: #fff;
        }
        .timeline {
            list-style: none;
            padding: 0;
        }
        .timeline li {
            margin-bottom: 40px;
            position: relative;
        }
        .timeline li:before {
            content: "";
            position: absolute;
            top: 0;
            left: 50%;
            margin-left: -3px;
            width: 6px;
            height: 100%;
            background-color: purple;
        }
        .timeline li:last-child {
            margin-bottom: 0;
        }
        .timeline li:last-child:before {
            height: 50%;
        }
        .timeline h3 {
            margin-top: 0;
            font-size: 20px;
        }
        .timeline p {
            margin: 10px 0;
        }
        .values {
            display: flex;
            justify-content: space-around;
            margin-top: 40px;
        }
        .value {
            flex: 1;
            text-align: center;
        }
        .team {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }
        .team-member {
            flex: 0 1 200px;
            margin: 10px;
            text-align: center;
        }
    </style>
</head>

<body background="background/background.jpg">

<header>
  <!--nav start-->
    <div class="navbar">
            <div class="logo">Xenovia</div>
            <nav>
                <ul class="nav-links">
                <a href="store.php">Store</a>&nbsp; &nbsp; &nbsp;
                <a href="contact.php">Contact us</a>&nbsp; &nbsp; &nbsp;
                <a href="about.php">About us</a>&nbsp; &nbsp; &nbsp;
                <?php 
                    session_start();
                ?>
                <?php
                    if(strlen($_SESSION['sid'])==0){
                      echo "<a href='register.php'>Register</a>&nbsp; &nbsp; &nbsp;";
                          echo "<a href='login.php'>Login</a>&nbsp; &nbsp; &nbsp;" ;
                          }else{
                            echo $_SESSION['email'];
                          }
                  ?>
            
                </ul>
                <div class="hamburger">
                    <div class="line"></div>
                    <div class="line"></div>
                    <div class="line"></div>
                </div>
            </nav>
        </div>
    
    <div class="sidenav">
        <a href="store.php">Store</a>
        <a href="register.php">Register</a>
        <a href="login.php">Login</a>
        <a href="contact.php">Contact us</a>
        <a href="about.php">About us</a>
    </div>
    <script>
      document.querySelector('.hamburger').addEventListener('click', () => {
      document.querySelector('.sidenav').style.width = '250px';
      });

      // document.querySelector('.sidenav').addEventListener('click', () => {
      // document.querySelector('.sidenav').style.width = '0';
      //});

      let slideIndex = 0;
    </script>
    <!--nav end-->
    <h1>About Us - <font color="lightblue" size="10">[Xenovia]</font></h1>
</header>

<div class="container">
    <section>
        <h2>Our Story</h2>
        <ul class="timeline">
            <li>
                <h3>Year 2024</h3>
                <p>We're start since 2024...</p>
            </li>
            <!-- Add more timeline items as needed -->
        </ul>
    </section>

    <section>
        <h2>Our Mission</h2>
        <p>Our goal is become a world wide online shopping...</p>
    </section>

    <section>
        <h2>Our Values</h2>
        <div class="values">
            <div class="value">
                <h3>Innovation</h3>
                <p>Our innovation is Blah Blah Blah...</p>
            </div>
            <!-- Add more values as needed -->
        </div>
    </section>

    <section>
        <h2>Meet the Team</h2>
        <div class="team">
            <div class="team-member">
                <img src="background/founder.png" alt="Team Member 1">
                <h3>Anonymous</h3>
                <p>Role: Founder</p>
            </div>
            <!-- Add more team members as needed -->
        </div>
    </section>
</div>

  <!-- Footer start -->
  <footer class="footer">
    <div class="waves">
      <div class="wave" id="wave1"></div>
      <div class="wave" id="wave2"></div>
      <div class="wave" id="wave3"></div>
      <div class="wave" id="wave4"></div>
    </div>
    <ul class="social-icon">
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-facebook"></ion-icon>
        </a></li>
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-twitter"></ion-icon>
        </a></li>
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-linkedin"></ion-icon>
        </a></li>
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-instagram"></ion-icon>
        </a></li>
    </ul>
    <ul class="menu">
      <li class="menu__item"><a class="menu__link" href="store.php">Store</a></li>
      <li class="menu__item"><a class="menu__link" href="register.php">Register</a></li>
      <li class="menu__item"><a class="menu__link" href="login.php">Login</a></li>
      <li class="menu__item"><a class="menu__link" href="contact.php">Contact us</a></li>
      <li class="menu__item"><a class="menu__link" href="about.php">About us</a></li>

    </ul>
    <p>&copy;2024 Xenovia | All Rights Reserved</p>
  </footer>
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
  
<script src="script.js"></script>

</body>
</html>
